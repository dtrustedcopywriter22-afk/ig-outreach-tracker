# IG Outreach Tracker — Android v0.1

This first version is deliberately simple and private.

## What it does
- Stores today's DM count locally on the phone.
- One-tap `+ DM SENT` counter.
- Can read Instagram notifications after you explicitly enable Android Notification Access.
- Attempts to count likely incoming Instagram message notifications.
- Calculates today's reply rate.

## Important limitation
Instagram normally does not generate a notification for every outgoing DM you send. Therefore Android's notification system cannot reliably count every cold DM you send.

The next version can explore a faster logging method (notification/quick tile/share shortcut) and a home-screen widget. We should not automate sending DMs or scrape Instagram credentials.

## Build
Open this folder in Android Studio, let Gradle sync, then run the app on an Android device/emulator.
