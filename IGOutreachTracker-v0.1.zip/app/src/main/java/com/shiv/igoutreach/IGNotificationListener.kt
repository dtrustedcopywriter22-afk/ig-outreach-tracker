package com.shiv.igoutreach

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class IGNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        // Instagram does not expose outgoing cold-DM sends as normal notifications.
        // We therefore only auto-count likely incoming replies here.
        if (sbn.packageName != "com.instagram.android") return

        val text = sbn.notification.extras.getCharSequence("android.text")
            ?.toString()?.lowercase() ?: return

        val title = sbn.notification.extras.getCharSequence("android.title")
            ?.toString()?.lowercase() ?: ""

        val looksLikeMessage =
            text.contains("sent you a message") ||
            text.contains("message request") ||
            title.contains("instagram")

        if (looksLikeMessage) {
            StatsStore.addReply(this)
        }
    }
}
