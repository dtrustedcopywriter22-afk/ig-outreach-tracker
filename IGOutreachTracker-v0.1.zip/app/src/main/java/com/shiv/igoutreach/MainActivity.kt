package com.shiv.igoutreach

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var stats: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 40)
            setBackgroundColor(0xFF000000.toInt())
        }

        val title = TextView(this).apply {
            text = "IG OUTREACH"
            textSize = 28f
            setTextColor(0xFF39FF14.toInt())
        }

        stats = TextView(this).apply {
            textSize = 20f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 50, 0, 50)
        }

        val dmButton = Button(this).apply {
            text = "+  DM SENT"
            setOnClickListener {
                StatsStore.addDm(this@MainActivity)
                refresh()
            }
        }

        val notificationButton = Button(this).apply {
            text = "ENABLE AUTO REPLY TRACKING"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }

        layout.addView(title)
        layout.addView(stats)
        layout.addView(dmButton)
        layout.addView(notificationButton)

        setContentView(layout)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val dms = StatsStore.todayDms(this)
        val replies = StatsStore.todayReplies(this)
        val rate = if (dms == 0) 0.0 else replies * 100.0 / dms
        stats.text = "TODAY\n\nDMs sent: $dms\nReplies: $replies\nReply rate: %.1f%%".format(rate)
    }
}
