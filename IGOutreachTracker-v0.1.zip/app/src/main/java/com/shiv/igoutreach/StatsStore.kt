package com.shiv.igoutreach

import android.content.Context
import java.time.LocalDate

object StatsStore {
    private const val PREFS = "stats"
    private const val DMS = "dms_"
    private const val REPLIES = "replies_"

    fun addDm(context: Context) {
        val day = LocalDate.now().toString()
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        p.edit().putInt(DMS + day, p.getInt(DMS + day, 0) + 1).apply()
    }

    fun addReply(context: Context) {
        val day = LocalDate.now().toString()
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        p.edit().putInt(REPLIES + day, p.getInt(REPLIES + day, 0) + 1).apply()
    }

    fun todayDms(context: Context): Int {
        val day = LocalDate.now().toString()
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getInt(DMS + day, 0)
    }

    fun todayReplies(context: Context): Int {
        val day = LocalDate.now().toString()
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getInt(REPLIES + day, 0)
    }
}
